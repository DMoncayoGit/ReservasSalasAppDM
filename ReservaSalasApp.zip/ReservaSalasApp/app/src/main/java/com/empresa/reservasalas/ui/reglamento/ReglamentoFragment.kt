package com.empresa.reservasalas.ui.reglamento

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import com.empresa.reservasalas.R
import android.widget.Toast

class ReglamentoFragment : Fragment() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragmento_reglamento, container, false)

        try {
            val webView = view.findViewById<WebView>(R.id.webView)
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            webView.settings.allowFileAccess = true
            webView.webViewClient = WebViewClient()

            // Usar visor de Google Drive
            val pdfId = "1wUW4m0vGHfhPMbtWVDjPWkEwoy-ReJjW"
            val viewerUrl = "https://drive.google.com/file/d/$pdfId/preview"
            webView.loadUrl(viewerUrl)

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error al cargar el PDF", Toast.LENGTH_LONG).show()
        }

        return view
    }
}